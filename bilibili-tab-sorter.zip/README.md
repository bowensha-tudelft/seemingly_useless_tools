# Bilibili Tab Sorter

Chrome 扩展 — 按视频时长排序已打开的 B 站标签页。

## 功能

- 扫描当前窗口所有 `*.bilibili.com` 标签页，自动提取视频时长
- 按时长从短到长排序标签页，非 B 站标签页保持原位置不动
- 摘要行显示未固定视频的合计时长（"共约 xx 分钟"）
- 检测 Chrome 休眠标签页，支持一键唤醒后重新扫描
- 支持固定标签页——按视频 URL 持久化，重启浏览器后自动恢复固定状态
- 固定标签页不参与唤醒、不参与排序
- 纯本地运行，不请求任何外部服务器

## 安装

1. 打开 Chrome，地址栏输入 `chrome://extensions/`
2. 右上角开启「开发者模式」
3. 点击「加载已解压的扩展程序」，选择当前目录

## 使用

1. 打开若干 B 站视频页面
2. 点击浏览器工具栏的扩展图标，弹出面板显示所有 B 站标签页及其时长
3. 点击「按时长排序」重排标签页顺序
4. 休眠的标签页点击「唤醒」后自动恢复并重新检测
5. 点击标签页右侧的 📌 按钮可固定/取消固定

## 时长提取原理

优先直接读取页面 `window.__INITIAL_STATE__`（需 MAIN world 注入），按以下顺序降级：

1. `videoData.duration` / `videoInfo.duration` / `epInfo.duration`
2. 遍历顶层 key 查找 duration/timelength
3. 嵌套结构 `epList` / `sections` / `pages` 的首项
4. DOM 内 `<script>` 标签中的 `__INITIAL_STATE__` JSON 解析
5. JSON-LD / meta itemprop / 播放器时间显示元素

## 文件

| 文件 | 说明 |
|---|---|
| `manifest.json` | Manifest V3 配置，权限声明 |
| `popup.html` | 弹出面板 UI |
| `popup.js` | 核心逻辑：标签页查询、脚本注入、时长提取、排序、唤醒、固定、合计时长 |
| `icon16.png` | 工具栏图标 16px |
| `icon48.png` | 工具栏图标 48px |
| `icon128.png` | 工具栏图标 128px |
