# DeepSeek Usage Pricing

Chrome 扩展 — 在 DeepSeek Platform 的 Usage 页面，鼠标悬停 Tokens 柱状图时，在每个 token 项目后面显示对应的价格。

## 效果

原始 tooltip：
```
Input (Cache hit)   7,274,240 tokens
Input (Cache miss)  292,545 tokens
Output              49,315 tokens
```

安装扩展后：
```
Input (Cache hit)   7,274,240 tokens, ¥0.18
Input (Cache miss)  292,545 tokens, ¥0.88
Output              49,315 tokens, ¥0.30
```

## 安装

1. 打开 Chrome，访问 `chrome://extensions/`
2. 开启右上角 **开发者模式 (Developer mode)**
3. 点击 **加载已解压的扩展程序 (Load unpacked)**
4. 选择 `deepseek-pricing-extension` 文件夹
5. 访问 https://platform.deepseek.com/usage 即可看到效果

## 价格数据来源

定价来自 [DeepSeek API 文档](https://api-docs.deepseek.com/zh-cn/quick_start/pricing)（人民币）：

| 模型 | Input (Cache hit) | Input (Cache miss) | Output |
|------|-------------------|--------------------|--------|
| deepseek-v4-pro | ¥0.025 / 1M tokens | ¥3 / 1M tokens | ¥6 / 1M tokens |
| deepseek-v4-flash | ¥0.02 / 1M tokens | ¥1 / 1M tokens | ¥2 / 1M tokens |

## 原理

- 通过 MutationObserver 监听页面 DOM 变化
- 检测 tooltip 元素中是否包含 token 信息
- 通过位置匹配找到对应的模型名称
- 解析 token 数量 × 单价 = 价格
- 直接修改 tooltip 文本，追加 `, ¥X.XX`
